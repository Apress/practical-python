# A function definition:
def square(x):
    'Calculates the square of the number x.'
    return x*x
