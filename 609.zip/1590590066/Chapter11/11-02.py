Your mother was a hamster and your
father smelled of elderberries.
