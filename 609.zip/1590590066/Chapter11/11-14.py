f = open(filename)
for line in f:
    process(line)
