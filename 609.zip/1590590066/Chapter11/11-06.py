this
isn't a
haiku
