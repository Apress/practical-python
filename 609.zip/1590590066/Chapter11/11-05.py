this
is no
haiku
