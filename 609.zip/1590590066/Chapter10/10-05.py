# reverseargs.py
import sys
args = sys.argv[1:]
args.reverse()
print ' '.join(args)
