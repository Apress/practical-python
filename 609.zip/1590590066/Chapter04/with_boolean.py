# Note that number <= 10 and number >= 1 could be written
# 1 <= number <= 10
if number <= 10 and number >= 1:
    print 'Great!'
else:
    print 'Wrong!'
