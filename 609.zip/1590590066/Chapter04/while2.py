name = ''
while not name:
    name = raw_input('Please enter your name: ')
print 'Hello, %s!' % name
