log('Starting program')

log('Trying to divide 1 by 0')

print 1 / 0

log('The division succeeded')

log('Ending program')
