from anygui import *
app = Application()
win = Window()
app.add(win)
app.run()
